package com.example.memmonitor.data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

/** 全局内存数据，来自 /proc/meminfo，单位统一为 KB */
public class MemoryStats {

    public long totalKb;
    public long freeKb;
    public long availableKb;
    public long buffersKb;
    public long cachedKb;
    public long swapCachedKb;
    public long swapTotalKb;
    public long swapFreeKb;
    public long activeKb;
    public long inactiveKb;
    public long dirtyKb;
    public long writebackKb;
    public long slabKb;
    public long vmAllocatedKb;   // 用户态已用（total - available 近似）

    public static MemoryStats read() {
        MemoryStats s = new MemoryStats();
        Map<String, Long> map = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/meminfo"))) {
            String line;
            while ((line = br.readLine()) != null) {
                int colon = line.indexOf(':');
                if (colon < 0) continue;
                String key = line.substring(0, colon).trim();
                String val = line.substring(colon + 1).replace("kB", "").trim();
                try {
                    map.put(key, Long.parseLong(val));
                } catch (Exception ignore) {
                }
            }
        } catch (Exception ignore) {
        }

        s.totalKb = val(map, "MemTotal");
        s.freeKb = val(map, "MemFree");
        s.availableKb = val(map, "MemAvailable");
        s.buffersKb = val(map, "Buffers");
        s.cachedKb = val(map, "Cached");
        s.swapCachedKb = val(map, "SwapCached");
        s.swapTotalKb = val(map, "SwapTotal");
        s.swapFreeKb = val(map, "SwapFree");
        s.activeKb = val(map, "Active");
        s.inactiveKb = val(map, "Inactive");
        s.dirtyKb = val(map, "Dirty");
        s.writebackKb = val(map, "Writeback");
        s.slabKb = val(map, "Slab");

        // MemAvailable 可能不存在于旧内核，回退用 MemFree + Buffers + Cached
        if (s.availableKb <= 0) {
            s.availableKb = s.freeKb + s.buffersKb + s.cachedKb;
        }
        s.vmAllocatedKb = Math.max(0, s.totalKb - s.availableKb);
        return s;
    }

    private static long val(Map<String, Long> map, String key) {
        Long v = map.get(key);
        return v == null ? 0 : v;
    }

    /** 已用百分比（0-100） */
    public int usedPercent() {
        if (totalKb <= 0) return 0;
        return (int) Math.round(vmAllocatedKb * 100.0 / totalKb);
    }

    /** 已用内存（MB） */
    public long usedMb() {
        return vmAllocatedKb / 1024;
    }

    public long totalMb() {
        return totalKb / 1024;
    }

    public long freeMb() {
        return freeKb / 1024;
    }

    public long availableMb() {
        return availableKb / 1024;
    }

    public long cachedMb() {
        return cachedKb / 1024;
    }

    public long buffersMb() {
        return buffersKb / 1024;
    }

    public long swapUsedMb() {
        return Math.max(0, (swapTotalKb - swapFreeKb) / 1024);
    }

    public long swapTotalMb() {
        return swapTotalKb / 1024;
    }

    /** 格式化为 x.x GB / xxx MB */
    public static String fmt(long kb) {
        if (kb >= 1048576) {
            return String.format("%.2f GB", kb / 1048576.0);
        }
        return String.format("%.0f MB", kb / 1024.0);
    }
}

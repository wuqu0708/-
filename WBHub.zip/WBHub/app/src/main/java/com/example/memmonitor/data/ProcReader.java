package com.example.memmonitor.data;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Debug;
import android.text.TextUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * 通过 /proc 目录解析每个进程的内存占用。
 * VmRSS 是进程实际占用的物理内存，是最准确的单进程指标；
 * 多进程会重复计算共享页，所以"后台占用之和"可能略大于系统总量，属正常现象。
 */
public class ProcReader {

    public static List<ProcInfo> read(ActivityManager am, PackageManager pm) {
        List<ProcInfo> list = new ArrayList<>();
        File procDir = new File("/proc");
        File[] entries = procDir.listFiles();
        if (entries == null) return list;

        for (File f : entries) {
            if (!f.isDirectory()) continue;
            String name = f.getName();
            if (!TextUtils.isDigitsOnly(name)) continue;
            int pid;
            try {
                pid = Integer.parseInt(name);
            } catch (Exception e) {
                continue;
            }

            ProcInfo info = new ProcInfo();
            info.pid = pid;
            info.rssKb = readRssKb(pid);
            if (info.rssKb <= 0) continue; // 无权限或已退出的进程

            info.name = readCmdline(pid);
            if (TextUtils.isEmpty(info.name)) continue;
            if (info.name.startsWith("/")) info.name = info.name.substring(1);

            // 尝试从包名反查
            if (info.name.contains(":")) {
                info.pkg = info.name.substring(0, info.name.indexOf(":"));
            } else {
                info.pkg = info.name;
            }

            try {
                ApplicationInfo ai = pm.getApplicationInfo(info.pkg, 0);
                info.isSystem = (ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
                info.icon = pm.getApplicationIcon(ai);
            } catch (Exception ignore) {
                // 非包进程（内核线程等）
            }

            info.importance = getImportance(am, pid);
            info.isForeground = info.importance <= 130;

            list.add(info);
        }

        // 内存占用从大到小排序
        list.sort((a, b) -> Long.compare(b.rssKb, a.rssKb));
        return list;
    }

    /** 读取 VmRSS，单位 KB */
    private static long readRssKb(int pid) {
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/" + pid + "/status"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("VmRSS:")) {
                    String[] parts = line.replace("kB", "").trim().split("\\s+");
                    if (parts.length >= 2) {
                        return Long.parseLong(parts[1]);
                    }
                }
            }
        } catch (Exception ignore) {
        }
        return 0;
    }

    /** 读取进程名 */
    private static String readCmdline(int pid) {
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/" + pid + "/cmdline"))) {
            StringBuilder sb = new StringBuilder();
            int c;
            while ((c = br.read()) != -1) {
                if (c == 0) break; // 参数以 \0 分隔
                sb.append((char) c);
            }
            String s = sb.toString().trim();
            if (!s.isEmpty()) return s;
        } catch (Exception ignore) {
        }
        // 回退到 status 的 Name 字段
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/" + pid + "/status"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("Name:")) {
                    return line.substring(5).trim();
                }
            }
        } catch (Exception ignore) {
        }
        return null;
    }

    private static int getImportance(ActivityManager am, int pid) {
        try {
            List<ActivityManager.RunningAppProcessInfo> procs = am.getRunningAppProcesses();
            if (procs != null) {
                for (ActivityManager.RunningAppProcessInfo p : procs) {
                    if (p.pid == pid) return p.importance;
                }
            }
        } catch (Exception ignore) {
        }
        return 400;
    }

    /** 本进程自身的内存信息（Debug.MemoryInfo） */
    public static Debug.MemoryInfo selfMemory(Context ctx) {
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        return am == null ? null : am.getProcessMemoryInfo(new int[]{android.os.Process.myPid()})[0];
    }
}

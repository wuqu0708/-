package com.example.memmonitor.data;

import android.graphics.drawable.Drawable;

/** 单个进程的信息 */
public class ProcInfo {
    public String pkg;       // 包名
    public String name;      // 进程名
    public int pid;
    public int uid;
    public long rssKb;       // 实际物理内存占用（PSS 近似，来自 /proc/pid/status 的 VmRSS）
    public int importance;   // ActivityManager.RunningAppProcessInfo.IMPORTANCE_*
    public boolean isSystem;
    public boolean isForeground; // 是否前台（重要度 <= IMPORTANCE_FOREGROUND_SERVICE 视为用户可见）
    public Drawable icon;

    /** 本进程是否为系统关键进程（system_server / systemui 等），默认受保护 */
    public boolean isCritical() {
        return isSystem && ("android".equals(pkg) || "com.android.systemui".equals(pkg)
                || "system_server".equals(name) || "com.android.phone".equals(pkg));
    }

    public String getImportanceText() {
        switch (importance) {
            case 100: return "前台";
            case 125: return "可见";
            case 130: return "前台服务";
            case 200: return "可感知";
            case 230: return "服务";
            case 300: return "后台";
            case 400: return "缓存";
            case 500: return "空进程";
            default: return "未知(" + importance + ")";
        }
    }
}

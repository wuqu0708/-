package com.example.memmonitor.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * 圆环进度条：外圈运存占用，中间显示百分比。
 * 支持颜色随占用等级变化。
 */
public class CircleProgressView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private float strokeWidth = 28f;
    private float progress = 0f;      // 0-100
    private float animatedProgress = 0f;
    private String centerText = "0%";
    private String subText = "";

    private int colorSafe = Color.parseColor("#4CAF50");
    private int colorWarn = Color.parseColor("#FFB300");
    private int colorDanger = Color.parseColor("#FF5252");

    public CircleProgressView(Context ctx) {
        super(ctx);
        init();
    }

    public CircleProgressView(Context ctx, AttributeSet attrs) {
        super(ctx, attrs);
        init();
    }

    public CircleProgressView(Context ctx, AttributeSet attrs, int defStyleAttr) {
        super(ctx, attrs, defStyleAttr);
        init();
    }

    private void init() {
        float density = getResources().getDisplayMetrics().density;
        strokeWidth = 14 * density;

        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(strokeWidth);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);
        trackPaint.setColor(Color.parseColor("#1F000000"));

        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(strokeWidth);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        progressPaint.setColor(colorSafe);

        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(46 * getResources().getDisplayMetrics().scaledDensity);

        subTextPaint.setColor(Color.parseColor("#B3FFFFFF"));
        subTextPaint.setTextAlign(Paint.Align.CENTER);
        subTextPaint.setTextSize(13 * getResources().getDisplayMetrics().scaledDensity);
    }

    /** 设置进度（0-100），带平滑动画 */
    public void setProgress(float p) {
        p = Math.max(0, Math.min(100, p));
        if (Math.abs(p - progress) < 0.1) {
            progress = p;
            animatedProgress = p;
            invalidate();
            return;
        }
        float from = animatedProgress;
        float to = p;
        ValueAnimator anim = ValueAnimator.ofFloat(from, to);
        anim.setDuration(400);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            animatedProgress = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
        progress = p;
    }

    public void setCenterText(String t) {
        this.centerText = t;
        invalidate();
    }

    public void setSubText(String t) {
        this.subText = t;
        invalidate();
    }

    public float getProgress() {
        return progress;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int size = Math.min(getWidth(), getHeight());
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float radius = size / 2f - strokeWidth / 2f - 4;

        rect.set(cx - radius, cy - radius, cx + radius, cy + radius);

        // 底环
        canvas.drawArc(rect, 0, 360, false, trackPaint);

        // 进度环
        int color = animatedProgress >= 85 ? colorDanger
                : animatedProgress >= 70 ? colorWarn : colorSafe;
        progressPaint.setColor(color);
        float sweep = animatedProgress * 3.6f;
        canvas.drawArc(rect, -90, sweep, false, progressPaint);

        // 中心文字
        float textY = cy - (textPaint.descent() + textPaint.ascent()) / 2f;
        canvas.drawText(centerText, cx, textY, textPaint);

        if (subText != null && !subText.isEmpty()) {
            canvas.drawText(subText, cx, cy + 32 * getResources().getDisplayMetrics().density, subTextPaint);
        }
    }
}

package com.example.memmonitor.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.memmonitor.service.MemMonitorService;

/** 开机自启：让监测服务在重启后自动恢复 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            MemMonitorService.start(context, 1000);
        }
    }
}

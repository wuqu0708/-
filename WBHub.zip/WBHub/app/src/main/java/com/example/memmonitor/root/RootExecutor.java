package com.example.memmonitor.root;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;

/**
 * Root 命令执行器。
 *
 * 说明：
 * 1. Android 的 am kill / killall 等命令受 SELinux 与权限限制，
 *    普通 shell 用户基本杀不掉后台进程，必须借助 su。
 * 2. 这里做了多超时路径探测：su 可能存在于 /system/bin/su、/system/xbin/su，
 *    也可能只被 magisk 挂载在 PATH 中。
 * 3. 执行时通过 exit 值判断是否真正拿到 root，避免"假成功"。
 */
public final class RootExecutor {

    private RootExecutor() {
    }

    /** root 状态 */
    public enum RootState {
        UNKNOWN, GRANTED, DENIED, NO_SU
    }

    private static RootState state = RootState.UNKNOWN;

    public static RootState getState() {
        return state;
    }

    /** 查找可用的 su 路径 */
    public static String findSu() {
        String[] candidates = {
                "/system/bin/su",
                "/system/xbin/su",
                "/sbin/su",
                "/su/bin/su",
                "/debug_ramdisk/su",
                "/vendor/bin/su"
        };
        for (String p : candidates) {
            File f = new File(p);
            if (f.exists() && f.canExecute()) return p;
        }
        // PATH 查找
        String path = System.getenv("PATH");
        if (path != null) {
            for (String dir : path.split(":")) {
                File f = new File(dir, "su");
                if (f.exists() && f.canExecute()) return f.getAbsolutePath();
            }
        }
        return null;
    }

    public static boolean hasSu() {
        return findSu() != null;
    }

    /** 检测 root 是否真的可用（会向用户请求授权） */
    public static RootState check(boolean request) {
        String su = findSu();
        if (su == null) {
            state = RootState.NO_SU;
            return state;
        }
        if (!request && state == RootState.GRANTED) return state;

        CommandResult r = exec(new String[]{"id"});
        if (r.exitCode == 0 && r.output.contains("uid=0")) {
            state = RootState.GRANTED;
        } else if (r.output.toLowerCase().contains("denied")
                || r.output.toLowerCase().contains("not allowed")) {
            state = RootState.DENIED;
        } else {
            state = RootState.DENIED;
        }
        return state;
    }

    public static class CommandResult {
        public int exitCode = -1;
        public String output = "";
        public boolean success;

        public CommandResult(int exitCode, String output) {
            this.exitCode = exitCode;
            this.output = output;
            this.success = exitCode == 0;
        }

        @Override
        public String toString() {
            return "exit=" + exitCode + "\n" + output;
        }
    }

    /** 执行单条 root 命令 */
    public static CommandResult exec(String command) {
        return exec(new String[]{command});
    }

    /** 执行多条 root 命令（同一会话，最后一条用 exit 取返回码） */
    public static CommandResult exec(String[] commands) {
        String su = findSu();
        if (su == null) {
            return new CommandResult(-1, "未找到 su 二进制文件");
        }
        Process process = null;
        DataOutputStream os = null;
        StringBuilder out = new StringBuilder();
        try {
            process = new ProcessBuilder(su).redirectErrorStream(true).start();
            os = new DataOutputStream(process.getOutputStream());
            for (String cmd : commands) {
                os.writeBytes(cmd + "\n");
            }
            os.writeBytes("echo __EXIT__$?\n");
            os.writeBytes("exit\n");
            os.flush();

            try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("__EXIT__")) {
                        try {
                            // 形如 __EXIT__0
                            String code = line.substring("__EXIT__".length()).trim();
                            int parsed = Integer.parseInt(code);
                            out.append("[exit ").append(parsed).append("]");
                        } catch (Exception ignore) {
                        }
                        break;
                    }
                    out.append(line).append("\n");
                }
            }

            int code = extractExit(out.toString());
            CommandResult r = new CommandResult(code, out.toString().trim());
            if (r.success) state = RootState.GRANTED;
            return r;
        } catch (Exception e) {
            return new CommandResult(-1, "执行失败: " + e.getMessage());
        } finally {
            try {
                if (os != null) os.close();
            } catch (Exception ignore) {
            }
            if (process != null) process.destroy();
        }
    }

    private static int extractExit(String s) {
        int idx = s.indexOf("[exit ");
        if (idx >= 0) {
            int end = s.indexOf("]", idx);
            if (end > idx) {
                try {
                    return Integer.parseInt(s.substring(idx + 6, end).trim());
                } catch (Exception ignore) {
                }
            }
        }
        return -1;
    }

    /** 快捷：以 root 执行 am 命令 */
    public static CommandResult am(String args) {
        return exec("am " + args);
    }

    /** 快捷：杀掉指定包的所有进程（root） */
    public static CommandResult forceStop(String pkg) {
        return exec("am force-stop " + pkg);
    }

    /** 触发系统 LMK 低内存回收，效果温和 */
    public static CommandResult trimMemory() {
        return exec(new String[]{
                "echo 3 > /proc/sys/vm/drop_caches",
                "sync"
        });
    }
}

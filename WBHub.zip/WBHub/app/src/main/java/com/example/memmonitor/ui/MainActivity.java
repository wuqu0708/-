package com.example.memmonitor.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.memmonitor.R;
import com.example.memmonitor.clean.MemoryCleaner;
import com.example.memmonitor.data.MemoryStats;
import com.example.memmonitor.data.ProcInfo;
import com.example.memmonitor.data.ProcReader;
import com.example.memmonitor.root.RootExecutor;
import com.example.memmonitor.service.FloatingWindowService;
import com.example.memmonitor.service.MemMonitorService;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private CircleProgressView circle;
    private TextView tvUsed, tvTotal, tvFree, tvCached, tvBuffers, tvSwap, tvProcCount;
    private TextView tvRootStatus, tvCleanLog;
    private MaterialButton btnClean, btnRoot, btnFloat, btnService;
    private MaterialSwitch swOnlyBackground;
    private Slider sliderInterval;
    private TextView tvInterval;
    private RecyclerView rv;
    private View progressOverlay;
    private ChipGroup chipFilter;

    private ProcAdapter adapter;
    private List<ProcInfo> allProcs = new ArrayList<>();
    private MemoryCleaner cleaner;
    private long intervalMs = 1000L;

    private final android.content.BroadcastReceiver receiver = new android.content.BroadcastReceiver() {
        @Override
        public void onReceive(android.content.Context context, android.content.Intent intent) {
            if (MemMonitorService.BROADCAST_UPDATE.equals(intent.getAction())) {
                int percent = intent.getIntExtra(MemMonitorService.EXTRA_PERCENT, 0);
                long used = intent.getLongExtra(MemMonitorService.EXTRA_USED, 0);
                long total = intent.getLongExtra(MemMonitorService.EXTRA_TOTAL, 0);
                updateCircle(percent, used, total);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();

        cleaner = new MemoryCleaner(this);

        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProcAdapter();
        rv.setAdapter(adapter);

        setupListeners();
        registerReceiver();
        requestNotificationPermission();
        checkRoot();
        refresh();

        MemMonitorService.start(this, intervalMs);
    }

    private void bindViews() {
        circle = findViewById(R.id.circle);
        tvUsed = findViewById(R.id.tv_used);
        tvTotal = findViewById(R.id.tv_total);
        tvFree = findViewById(R.id.tv_free);
        tvCached = findViewById(R.id.tv_cached);
        tvBuffers = findViewById(R.id.tv_buffers);
        tvSwap = findViewById(R.id.tv_swap);
        tvProcCount = findViewById(R.id.tv_proc_count);
        tvRootStatus = findViewById(R.id.tv_root_status);
        tvCleanLog = findViewById(R.id.tv_clean_log);
        btnClean = findViewById(R.id.btn_clean);
        btnRoot = findViewById(R.id.btn_root);
        btnFloat = findViewById(R.id.btn_float);
        btnService = findViewById(R.id.btn_service);
        swOnlyBackground = findViewById(R.id.sw_only_background);
        sliderInterval = findViewById(R.id.slider_interval);
        tvInterval = findViewById(R.id.tv_interval);
        rv = findViewById(R.id.rv_procs);
        progressOverlay = findViewById(R.id.progress_overlay);
        chipFilter = findViewById(R.id.chip_filter);
    }

    private void setupListeners() {
        btnClean.setOnClickListener(v -> confirmClean());
        btnRoot.setOnClickListener(v -> checkRoot());
        btnFloat.setOnClickListener(v -> toggleFloat());
        btnService.setOnClickListener(v -> {
            MemMonitorService.start(this, intervalMs);
            Toast.makeText(this, "监测间隔已设为 " + intervalMs + " ms", Toast.LENGTH_SHORT).show();
        });

        chipFilter.setOnCheckedStateChangeListener((group, checkedIds) -> applyFilter());

        sliderInterval.addOnChangeListener((slider, value, fromUser) -> {
            intervalMs = Math.max(200, (long) (value * 200L));
            tvInterval.setText(intervalMs + " ms");
        });

        sliderInterval.addOnSliderTouchListener(new Slider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(Slider slider) {
            }

            @Override
            public void onStopTrackingTouch(Slider slider) {
                MemMonitorService.start(MainActivity.this, intervalMs);
            }
        });
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }
    }

    private void registerReceiver() {
        android.content.IntentFilter f = new android.content.IntentFilter(MemMonitorService.BROADCAST_UPDATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, f, android.content.Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, f);
        }
    }

    private void updateCircle(int percent, long usedMb, long totalMb) {
        circle.setProgress(percent);
        circle.setCenterText(percent + "%");
        circle.setSubText(MemoryStats.fmt(usedMb * 1024L) + " / " + MemoryStats.fmt(totalMb * 1024L));
    }

    private void refresh() {
        new Thread(() -> {
            MemoryStats s = MemoryStats.read();
            android.app.ActivityManager am =
                    (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.content.pm.PackageManager pm = getPackageManager();
            List<ProcInfo> procs = ProcReader.read(am, pm);

            runOnUiThread(() -> {
                allProcs = procs;
                renderStats(s);
                applyFilter();
                tvProcCount.setText("进程 " + procs.size() + " 个");
            });
        }, "mem-read").start();
    }

    private void renderStats(MemoryStats s) {
        int percent = s.usedPercent();
        updateCircle(percent, s.usedMb(), s.totalMb());

        tvUsed.setText("已用 " + MemoryStats.fmt(s.vmAllocatedKb));
        tvTotal.setText("总运存 " + MemoryStats.fmt(s.totalKb));
        tvFree.setText("空闲 " + MemoryStats.fmt(s.freeKb));
        tvCached.setText("缓存 " + MemoryStats.fmt(s.cachedKb));
        tvBuffers.setText("Buffers " + MemoryStats.fmt(s.buffersKb));
        tvSwap.setText("Swap " + MemoryStats.fmt(Math.max(0, s.swapTotalKb - s.swapFreeKb))
                + " / " + MemoryStats.fmt(s.swapTotalKb));
    }

    private void applyFilter() {
        if (allProcs == null) return;
        List<ProcInfo> out = new ArrayList<>();
        int checkedId = chipFilter.getCheckedChipId();

        for (ProcInfo p : allProcs) {
            boolean keep = true;
            if (checkedId == R.id.chip_background) {
                keep = !p.isForeground;
            } else if (checkedId == R.id.chip_user) {
                keep = !p.isSystem;
            } else if (checkedId == R.id.chip_big) {
                keep = p.rssKb >= 100 * 1024;
            }
            if (keep) out.add(p);
        }
        adapter.setData(out);
    }

    private void checkRoot() {
        tvRootStatus.setText("Root: 检测中…");
        btnRoot.setEnabled(false);
        new Thread(() -> {
            RootExecutor.RootState st = RootExecutor.check(true);
            runOnUiThread(() -> {
                btnRoot.setEnabled(true);
                switch (st) {
                    case GRANTED:
                        tvRootStatus.setText("Root: 已授权 ✓");
                        Toast.makeText(this, "Root 已授权，可执行强力清理", Toast.LENGTH_SHORT).show();
                        break;
                    case NO_SU:
                        tvRootStatus.setText("Root: 设备未 Root");
                        Toast.makeText(this, "未检测到 su，将使用普通权限清理", Toast.LENGTH_LONG).show();
                        break;
                    default:
                        tvRootStatus.setText("Root: 被拒绝/不可用");
                        Toast.makeText(this, "Root 被拒绝，请在授权弹窗中允许", Toast.LENGTH_LONG).show();
                        break;
                }
            });
        }, "root-check").start();
    }

    private void confirmClean() {
        List<ProcInfo> targets = new ArrayList<>();
        boolean onlyBg = swOnlyBackground.isChecked();

        for (ProcInfo p : allProcs) {
            if (p.isCritical()) continue;
            if (onlyBg) {
                if (p.isForeground || p.isSystem) continue;
            }
            targets.add(p);
        }

        if (targets.isEmpty()) {
            Toast.makeText(this, "没有可清理的进程", Toast.LENGTH_SHORT).show();
            return;
        }

        long sumKb = 0;
        for (ProcInfo p : targets) sumKb += p.rssKb;

        new AlertDialog.Builder(this)
                .setTitle("清理运存")
                .setMessage("将结束 " + targets.size() + " 个进程（" + MemoryStats.fmt(sumKb) + "）\n\n"
                        + "• 前台应用与系统关键进程会被自动跳过\n"
                        + (RootExecutor.hasSu()
                        ? "• 已获得 Root，执行 am force-stop 强力清理"
                        : "• 无 Root，使用普通 kill（部分应用会被系统立刻拉起）"))
                .setPositiveButton("清理", (d, w) -> doClean(targets))
                .setNegativeButton("取消", null)
                .show();
    }

    private void doClean(List<ProcInfo> targets) {
        progressOverlay.setVisibility(View.VISIBLE);
        btnClean.setEnabled(false);
        tvCleanLog.setText("");

        cleaner.clean(targets, RootExecutor.hasSu(), new MemoryCleaner.Callback() {
            @Override
            public void onProgress(int done, int total, String currentPkg) {
                runOnUiThread(() -> tvCleanLog.setText("正在清理 " + done + "/" + total + " : " + currentPkg));
            }

            @Override
            public void onFinished(MemoryCleaner.CleanResult result) {
                runOnUiThread(() -> {
                    progressOverlay.setVisibility(View.GONE);
                    btnClean.setEnabled(true);

                    String msg = "完成：成功 " + result.killedCount
                            + " · 跳过 " + result.skippedCount
                            + " · 失败 " + result.failedCount
                            + "\n释放约 " + MemoryStats.fmt(result.freedKb);
                    tvCleanLog.setText(msg);

                    Toast.makeText(MainActivity.this,
                            "已结束 " + result.killedCount + " 个进程", Toast.LENGTH_SHORT).show();
                    refresh();
                });
            }
        });
    }

    private void toggleFloat() {
        if (FloatingWindowService.isRunning(this)) {
            FloatingWindowService.hide(this);
            btnFloat.setText("开启悬浮窗");
        } else if (Settings.canDrawOverlays(this)) {
            FloatingWindowService.show(this);
            btnFloat.setText("关闭悬浮窗");
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("需要悬浮窗权限")
                    .setMessage("开启后可在任何界面看到实时运存占用")
                    .setPositiveButton("去授权", (d, w) -> {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    })
                    .setNegativeButton("取消", null)
                    .show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        btnFloat.setText(FloatingWindowService.isRunning(this) ? "关闭悬浮窗" : "开启悬浮窗");
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignore) {
        }
        super.onDestroy();
    }

    /** 进程列表适配器 */
    static class ProcAdapter extends RecyclerView.Adapter<ProcAdapter.VH> {

        private List<ProcInfo> data = new ArrayList<>();

        public void setData(List<ProcInfo> list) {
            this.data = list == null ? new ArrayList<>() : list;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_proc, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            ProcInfo p = data.get(position);

            String label = p.pkg;
            try {
                label = h.itemView.getContext().getPackageManager()
                        .getApplicationLabel(
                                h.itemView.getContext().getPackageManager()
                                        .getApplicationInfo(p.pkg, 0)).toString();
            } catch (Exception ignore) {
            }

            h.tvName.setText(label);
            h.tvPkg.setText(p.pkg + (p.name.equals(p.pkg) ? "" : " · " + p.name));
            h.tvMem.setText(MemoryStats.fmt(p.rssKb));
            h.tvTag.setText(p.getImportanceText() + (p.isSystem ? " · 系统" : " · 第三方"));

            if (p.icon != null) {
                h.icon.setImageDrawable(p.icon);
            } else {
                h.icon.setImageResource(R.mipmap.ic_launcher);
            }

            // 颜色提示
            int color;
            if (p.isForeground) color = 0xFF4CAF50;
            else if (p.isSystem) color = 0xFF9E9E9E;
            else if (p.rssKb >= 300 * 1024) color = 0xFFFF5252;
            else color = 0xFFFFB300;
            h.tvMem.setTextColor(color);

            // 点击单独结束该进程
            h.itemView.setOnClickListener(v -> {
                if (p.isCritical()) {
                    Toast.makeText(v.getContext(), "系统关键进程，已跳过", Toast.LENGTH_SHORT).show();
                    return;
                }
                new AlertDialog.Builder(v.getContext())
                        .setTitle("结束进程")
                        .setMessage("结束 " + label + "？")
                        .setPositiveButton("结束", (d, w) -> {
                            new Thread(() -> {
                                boolean ok;
                                if (RootExecutor.hasSu()) {
                                    ok = RootExecutor.forceStop(p.pkg).success;
                                    if (!ok) ok = RootExecutor.exec("killall " + p.name).success;
                                } else {
                                    ok = true;
                                    android.app.ActivityManager am = (android.app.ActivityManager)
                                            v.getContext().getSystemService(ACTIVITY_SERVICE);
                                    am.killBackgroundProcesses(p.pkg);
                                }
                                v.post(() -> Toast.makeText(v.getContext(),
                                        ok ? "已结束 " + label : "结束失败", Toast.LENGTH_SHORT).show());
                            }).start();
                        })
                        .setNegativeButton("取消", null)
                        .show();
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static class VH extends RecyclerView.ViewHolder {
            ImageView icon;
            TextView tvName, tvPkg, tvMem, tvTag;

            VH(View v) {
                super(v);
                icon = v.findViewById(R.id.iv_icon);
                tvName = v.findViewById(R.id.tv_name);
                tvPkg = v.findViewById(R.id.tv_pkg);
                tvMem = v.findViewById(R.id.tv_mem);
                tvTag = v.findViewById(R.id.tv_tag);
            }
        }
    }
}

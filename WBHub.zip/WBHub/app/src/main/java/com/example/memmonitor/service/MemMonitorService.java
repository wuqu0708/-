package com.example.memmonitor.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.memmonitor.R;
import com.example.memmonitor.data.MemoryStats;
import com.example.memmonitor.ui.MainActivity;

import java.util.Locale;

/**
 * 前台服务：按固定间隔轮询内存，并更新常驻通知。
 * 这样退到桌面 / 锁屏后依然在统计，通知栏就是实时仪表盘。
 */
public class MemMonitorService extends Service {

    public static final String ACTION_START = "com.example.memmonitor.START";
    public static final String ACTION_STOP = "com.example.memmonitor.STOP";
    public static final String ACTION_REFRESH = "com.example.memmonitor.REFRESH";

    public static final String EXTRA_INTERVAL = "interval_ms";

    public static final String BROADCAST_UPDATE = "com.example.memmonitor.MEM_UPDATE";
    public static final String EXTRA_PERCENT = "percent";
    public static final String EXTRA_USED = "used_mb";
    public static final String EXTRA_TOTAL = "total_mb";

    private static final String CHANNEL_ID = "mem_monitor";
    private static final int NOTIFICATION_ID = 1001;

    private static final String PREF = "mem_monitor_pref";
    private static final String KEY_INTERVAL = "interval";
    private static final long DEFAULT_INTERVAL = 1000L;

    private Handler handler;
    private long intervalMs = DEFAULT_INTERVAL;
    private boolean running = false;
    private SharedPreferences pref;

    /** 供外部读取最新数据（悬浮窗等） */
    public static volatile MemoryStats latest = new MemoryStats();

    public static void start(Context ctx, long intervalMs) {
        Intent i = new Intent(ctx, MemMonitorService.class);
        i.setAction(ACTION_START);
        i.putExtra(EXTRA_INTERVAL, intervalMs);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    public static void stop(Context ctx) {
        Intent i = new Intent(ctx, MemMonitorService.class);
        i.setAction(ACTION_STOP);
        ctx.startService(i);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        pref = getSharedPreferences(PREF, MODE_PRIVATE);
        intervalMs = pref.getLong(KEY_INTERVAL, DEFAULT_INTERVAL);
        handler = new Handler(Looper.getMainLooper());
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && intent.hasExtra(EXTRA_INTERVAL)) {
            intervalMs = intent.getLongExtra(EXTRA_INTERVAL, DEFAULT_INTERVAL);
            pref.edit().putLong(KEY_INTERVAL, intervalMs).apply();
        }

        startForeground(NOTIFICATION_ID, buildNotification(latest));
        if (!running) {
            running = true;
            handler.post(tick);
        }
        return START_STICKY;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;

            MemoryStats s = MemoryStats.read();
            latest = s;

            // 更新通知
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.notify(NOTIFICATION_ID, buildNotification(s));
            }

            // 广播给界面
            Intent b = new Intent(BROADCAST_UPDATE);
            b.putExtra(EXTRA_PERCENT, s.usedPercent());
            b.putExtra(EXTRA_USED, s.usedMb());
            b.putExtra(EXTRA_TOTAL, s.totalMb());
            sendBroadcast(b);

            handler.postDelayed(this, intervalMs);
        }
    };

    private Notification buildNotification(MemoryStats s) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String title = String.format(Locale.US, "运存 %d%%  ·  %s / %s",
                s.usedPercent(), MemoryStats.fmt(s.vmAllocatedKb), MemoryStats.fmt(s.totalKb));
        String text = String.format(Locale.US, "可用 %s · 缓存 %s · 刷新 %dms",
                MemoryStats.fmt(s.availableKb), MemoryStats.fmt(s.cachedKb), intervalMs);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_mem)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID,
                    "运存实时监测", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("常驻显示当前内存占用");
            c.setShowBadge(false);
            c.enableVibration(false);
            c.setSound(null, null);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

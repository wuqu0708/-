package com.example.memmonitor.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.example.memmonitor.R;
import com.example.memmonitor.data.MemoryStats;

/**
 * 悬浮窗服务：在屏幕上显示一个可拖动的小球，实时显示运存占用。
 * 点击可展开/收起，长按可拖动位置。
 */
public class FloatingWindowService extends Service {

    public static final String ACTION_SHOW = "show";
    public static final String ACTION_HIDE = "hide";

    private static final String PREF = "float_pref";
    private static final String KEY_X = "x";
    private static final String KEY_Y = "y";

    private WindowManager wm;
    private View rootView;
    private WindowManager.LayoutParams params;
    private TextView tvCompact;
    private TextView tvDetail;
    private boolean expanded = false;

    private Handler handler;
    private final Runnable updater = new Runnable() {
        @Override
        public void run() {
            MemoryStats s = MemoryStats.read();
            if (tvCompact != null) {
                tvCompact.setText(s.usedPercent() + "%");
                int color = colorFor(s.usedPercent());
                tvCompact.setTextColor(color);
                if (rootView instanceof android.widget.LinearLayout) {
                    // 小球背景色随占用变化
                }
            }
            if (tvDetail != null && expanded) {
                tvDetail.setText(String.format("已用 %s\n可用 %s\n总计 %s\n缓存 %s",
                        MemoryStats.fmt(s.vmAllocatedKb),
                        MemoryStats.fmt(s.availableKb),
                        MemoryStats.fmt(s.totalKb),
                        MemoryStats.fmt(s.cachedKb)));
            }
            handler.postDelayed(this, 1000);
        }
    };

    private int colorFor(int percent) {
        if (percent >= 85) return 0xFFFF5252;
        if (percent >= 70) return 0xFFFFB300;
        return 0xFF4CAF50;
    }

    public static void show(Context ctx) {
        Intent i = new Intent(ctx, FloatingWindowService.class);
        i.setAction(ACTION_SHOW);
        ctx.startService(i);
    }

    public static void hide(Context ctx) {
        Intent i = new Intent(ctx, FloatingWindowService.class);
        i.setAction(ACTION_HIDE);
        ctx.startService(i);
    }

    public static boolean isRunning(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREF, MODE_PRIVATE);
        return p.getBoolean("running", false);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        handler = new Handler(Looper.getMainLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_HIDE.equals(intent.getAction())) {
            removeView();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (rootView == null) {
            addView();
        }
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean("running", true).apply();
        handler.removeCallbacks(updater);
        handler.post(updater);
        return START_STICKY;
    }

    private void addView() {
        int type;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences pref = getSharedPreferences(PREF, MODE_PRIVATE);
        params.x = pref.getInt(KEY_X, 40);
        params.y = pref.getInt(KEY_Y, 200);

        rootView = LayoutInflater.from(this).inflate(R.layout.floating_window, null);
        tvCompact = rootView.findViewById(R.id.tv_compact);
        tvDetail = rootView.findViewById(R.id.tv_detail);

        // 点击展开/收起
        rootView.setOnClickListener(v -> {
            expanded = !expanded;
            tvDetail.setVisibility(expanded ? View.VISIBLE : View.GONE);
        });

        // 拖动
        rootView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float touchX, touchY;
            private long downTime;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        downTime = System.currentTimeMillis();
                        moved = false;
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchX);
                        int dy = (int) (event.getRawY() - touchY);
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true;
                        params.x = initialX + dx;
                        params.y = initialY + dy;
                        try {
                            wm.updateViewLayout(rootView, params);
                        } catch (Exception ignore) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && System.currentTimeMillis() - downTime < 400) {
                            v.performClick();
                        }
                        savePos();
                        return true;
                }
                return false;
            }
        });

        try {
            wm.addView(rootView, params);
        } catch (Exception ignore) {
        }
    }

    private void savePos() {
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                .putInt(KEY_X, params.x)
                .putInt(KEY_Y, params.y)
                .apply();
    }

    private void removeView() {
        handler.removeCallbacks(updater);
        if (rootView != null) {
            try {
                wm.removeView(rootView);
            } catch (Exception ignore) {
            }
            rootView = null;
        }
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean("running", false).apply();
    }

    @Override
    public void onDestroy() {
        removeView();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

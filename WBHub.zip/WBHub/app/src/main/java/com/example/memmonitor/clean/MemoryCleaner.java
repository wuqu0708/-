package com.example.memmonitor.clean;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.example.memmonitor.data.ProcInfo;
import com.example.memmonitor.root.RootExecutor;

import java.util.ArrayList;
import java.util.List;

/**
 * 运存清理器。
 *
 * 清理分三个层级，从温和到激进：
 *   1. 普通层：ActivityManager.killBackgroundProcesses()（无需 root，但系统会很快拉回应用）
 *   2. Root 层：am force-stop <pkg>（真正结束应用全部进程，最有效）
 *   3. 系统层：drop_caches / trim（需要 root，回收内核页缓存，收益有限但能降 RSS）
 *
 * 注意：本类绝不触碰系统关键进程，避免造成系统不稳定。
 */
public class MemoryCleaner {

    public interface Callback {
        void onProgress(int done, int total, String currentPkg);

        void onFinished(CleanResult result);
    }

    public static class CleanResult {
        public int killedCount;          // 成功结束的进程数
        public int skippedCount;         // 被保护跳过的进程数
        public int failedCount;          // 失败数
        public long freedKb;             // 估算释放的内存 KB
        public boolean usedRoot;
        public List<String> detail = new ArrayList<>();
    }

    private final Context ctx;
    private final ActivityManager am;

    public MemoryCleaner(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
    }

    /**
     * 清理后台进程。
     *
     * @param procs    待清理列表（调用方负责筛选，比如只传后台 + 第三方）
     * @param useRoot  是否使用 root
     */
    public void clean(List<ProcInfo> procs, boolean useRoot, Callback callback) {
        final CleanResult result = new CleanResult();
        result.usedRoot = useRoot && RootExecutor.hasSu();

        final List<ProcInfo> targets = new ArrayList<>();
        for (ProcInfo p : procs) {
            if (p.isCritical() || p.isForeground) {
                result.skippedCount++;
                continue;
            }
            targets.add(p);
        }

        new Thread(() -> {
            int total = targets.size();
            int done = 0;
            // 清理前采样一次可用内存，用于估算释放量
            long beforeFree = com.example.memmonitor.data.MemoryStats.read().availableKb;
            long killedKb = 0;

            for (ProcInfo p : targets) {
                done++;
                if (callback != null) {
                    callback.onProgress(done, total, p.pkg);
                }

                boolean ok = false;

                if (result.usedRoot) {
                    RootExecutor.CommandResult r = RootExecutor.forceStop(p.pkg);
                    ok = r.success;
                    if (!ok) {
                        // 回退到 killall（某些定制 ROM 屏蔽了 am force-stop）
                        RootExecutor.CommandResult r2 = RootExecutor.exec("killall " + p.name);
                        ok = r2.success;
                        if (ok) {
                            result.detail.add(p.pkg + " → killall 成功");
                        } else {
                            result.detail.add(p.pkg + " → 失败: " + firstLine(r.output) + "/" + firstLine(r2.output));
                        }
                    } else {
                        result.detail.add(p.pkg + " → force-stop 成功");
                    }
                }

                if (!ok) {
                    // 普通权限回退
                    try {
                        am.killBackgroundProcesses(p.pkg);
                        ok = true;
                        result.detail.add(p.pkg + " → killBackgroundProcesses");
                    } catch (Exception e) {
                        result.detail.add(p.pkg + " → 异常: " + e.getMessage());
                    }
                }

                if (ok) {
                    result.killedCount++;
                    killedKb += p.rssKb;
                } else {
                    result.failedCount++;
                }

                // 每清理一个，稍作停顿，让系统有时间回收
                try {
                    Thread.sleep(120);
                } catch (InterruptedException ignore) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            // 内核层回收
            if (result.usedRoot) {
                RootExecutor.trimMemory();
            }

            // 重新采样，估算实际释放量（与"被杀进程 RSS 之和"取较大者）
            try {
                Thread.sleep(600);
            } catch (InterruptedException ignore) {
            }
            long after = com.example.memmonitor.data.MemoryStats.read().availableKb;
            long delta = after - beforeFree;
            result.freedKb = Math.max(delta, killedKb);

            if (callback != null) callback.onFinished(result);
        }, "mem-clean").start();
    }

    private static String firstLine(String s) {
        if (s == null || s.isEmpty()) return "";
        int idx = s.indexOf('\n');
        return idx > 0 ? s.substring(0, idx) : s;
    }

    /** 打开系统的应用详情页，方便用户手动限制自启 */
    public void openAppSettings(String pkg) {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(android.net.Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception ignore) {
        }
    }

    public static boolean isSupported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.N;
    }
}

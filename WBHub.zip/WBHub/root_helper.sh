// MemMonitor 的 Root 辅助脚本，可通过 adb / su 执行做验证
// 用法: sh root_helper.sh

echo "== 内存总览 =="
cat /proc/meminfo | head -8

echo ""
echo "== VmRSS 前 10 的进程 =="
for p in /proc/[0-9]*; do
    pid=${p#/proc/}
    rss=$(grep VmRSS "$p/status" 2>/dev/null | awk '{print $2}')
    name=$(tr -d '\0' < "$p/cmdline" 2>/dev/null)
    [ -z "$rss" ] && continue
    [ -z "$name" ] && continue
    echo "$rss KB  pid=$pid  $name"
done | sort -rn | head -10
